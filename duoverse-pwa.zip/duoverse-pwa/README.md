# DuoVerse — Zero-Backend 50-Game Duo Hub, Voice Chat & Synced Radio (PWA)

DuoVerse ek **100% zero-backend, installable Progressive Web App (PWA)** hai jahan koi bhi 2 log ek simple room code ya invite link se direct browser-to-browser connect hoke **50 games**, **live text chat**, **WebRTC voice chat**, aur **synced radio** enjoy kar sakte hain.

## Architecture & Tech Stack (Zero Build Step, Zero Backend)

- **Networking & Voice:** PeerJS (WebRTC DataChannel + WebRTC MediaStream) — direct P2P connection with Google/Twilio STUN servers, echo cancellation, and noise suppression.
- **50-Game Jugad:**
  - **8 Built-in Zero-Lag P2P Synced Duo Games** (`js/native-games.js`): Tic-Tac-Toe Neon, Connect 4 Cyber, Rock Paper Scissors, Memory Flip Duel, Draw & Guess Live (synced canvas), Reflex Duel (ms), Dots & Boxes, and Code Breaker 99.
  - **42 Verified Embeddable HTML5 Arcade Games** (`js/games-catalog.js`): Curated from [HTML5Games / Famobi](https://html5games.com/) (`play.famobi.com`) and [HTMLGames](https://www.htmlgames.com/html5-games-for-your-site/) (`cdn.htmlgames.com`). Launching any game syncs & opens it for both players simultaneously.
  - **Custom Game URL Launcher:** Paste any embeddable `https://` HTML5 game URL to play together.
- **Synced Duo Radio (`js/radio.js`):**
  - 8 curated ad-free HTTPS MP3 channels ([SomaFM](https://somafm.com/) including *Suburbs of Goa*, *Groove Salad*, *Vaporwaves*, *PopTron!*).
  - Live search across 30,000+ global, Bollywood, Hindi, Punjabi, and Lo-Fi FM streams via the open [Radio Browser API](https://api.radio-browser.info/).
  - Real-time P2P sync so both players hear the exact same station.
- **Installable PWA (`manifest.webmanifest` + `sw.js`):**
  - Standalone app mode, offline shell caching, custom PNG icons, and 1-click **Install App** button (`beforeinstallprompt`).

## 1-Minute Free Deploy (HTTPS Required for Voice Chat & PWA Install)

WebRTC Voice Chat aur PWA Install ke liye site **HTTPS** (ya `localhost`) par honi chahiye:

1. **Netlify Drop (Fastest — 15 seconds):**
   - Unzip `duoverse-pwa.zip`.
   - [app.netlify.com/drop](https://app.netlify.com/drop) kholo aur `duoverse-pwa` folder drag-and-drop kar do.
   - Turant live HTTPS link mil jayega!
2. **Vercel / Cloudflare Pages / GitHub Pages:**
   - Repo push karo ya folder upload karo — zero build command (`Build Command: none`, `Output Directory: .`).
3. **Local Testing:**
   ```bash
   npx serve .
   # OR
   python3 -m http.server 8080
   ```
   Open `http://localhost:8080` in 2 browser tabs to test Room Create/Join, Live Games, Chat, and Synced Radio!

## PWA Install Kaise Karein?

- **Chrome / Edge (Desktop & Android):** Deployed HTTPS link kholo aur top bar me **⬇ Install App** button click karo.
- **iOS Safari:** Share icon -> **Add to Home Screen** tap karo.
